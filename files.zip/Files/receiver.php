<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = file_get_contents('php://input');
    
    // Decode JSON data
    $json = json_decode($data, true);
    
    // Check if JSON decoding was successful
    if ($json === null) {
        http_response_code(400);
        echo 'Invalid JSON';
        exit;
    }

    // Extract device info
    if (isset($json['device_info'])) {
        $deviceInfo = $json['device_info'];
        $mac = $deviceInfo['mac'];
        $buildNumber = $deviceInfo['build_number'];
        $model = $deviceInfo['model'];
        $appList = $deviceInfo['app_list'];
        
        // Save device info to a file named based on the MAC address and model
        $deviceFile = $mac . '_' . $model . '.txt';
        $deviceInfoString = "MAC: $mac\nBuild Number: $buildNumber\nModel: $model\nApps:\n" . implode("\n", $appList) . "\n";
        file_put_contents($deviceFile, $deviceInfoString);
    }
    
    // Extract location data
    if (isset($json['location'])) {
        $location = $json['location'];
        $latitude = $location['latitude'];
        $longitude = $location['longitude'];
        
        // Check if device info exists in the request
        if (isset($json['device_info'])) {
            $mac = $json['device_info']['mac'];
            $model = $json['device_info']['model'];
            $deviceFile = $mac . '_' . $model . '.txt';
            
            // Save location data to the device info file
            if (file_exists($deviceFile)) {
                $locationData = "Last Known Location: Latitude: $latitude, Longitude: $longitude\n";
                file_put_contents($deviceFile, $locationData, FILE_APPEND);
            } else {
                http_response_code(400);
                echo 'Device info file not found';
                exit;
            }
        }
    }
    
    echo 'Data received';
} else {
    http_response_code(405);
    echo 'Method not allowed';
}
?>

