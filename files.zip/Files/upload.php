<?php
$target_path = "Uploaded/"; // Base folder name
$client_ip = $_SERVER['REMOTE_ADDR']; // Get client's IP address
$target_path = $target_path . $client_ip . '_' . basename($_FILES['uploadedfile']['name']);

error_log("Received File: " . basename($_FILES['uploadedfile']['name']) . " \r\n", 3, "Log.log");
error_log("Output: " . $target_path . " \r\n", 3, "Log.log");

if (move_uploaded_file($_FILES['uploadedfile']['tmp_name'], $target_path)) {
    echo "The file " . basename($_FILES['uploadedfile']['name']) . " has been uploaded";
} else {
    echo "There was an error uploading the file, please try again!";
}
?>

